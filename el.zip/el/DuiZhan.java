package duizhanzhuye;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
class MyTask1 extends TimerTask{
	private int time = 0;
	private boolean circum = true;
	public void run() {
		time = time+1;
		if(time==2) {
		    circum = false;
		    duizhanzhuye c = new duizhanzhuye();
		    boolean opp = c.getChan();
		    if(opp) {
		    	System.out.println("Time is up!");
		    }
			cancel();
		}
		
	}
	public boolean getCir() {
		return circum;
	}
}

public class DuiZhan {
	public static void main (String[] args) {
		//("1 secdvdvvffvfv?:a 1:b 2:c 3:d 4:a;2 cdvgrbdb?:a 1:b 2:c 3:d 4:c;3 gregrg?:a 1:b 2:c 3:d 4:b")
	    String text = "1 secdvdvvffvfv?:a 1:b 2:c 3:d 4:a;2 cdvgrbdb?:a 1:b 2:c 3:d 4:c;3 gregrg?:a 1:b 2:c 3:d 4:b";
	    String problem[] = text.split(";");
	    for(int i=0;i<problem.length;i++) {
		    String items[] = problem[i].split(":");
		    String question = items[0];
		    String answer1 = items[1];
		    String answer2 = items[2];
		    String answer3 = items[3];
		    String answer4 = items[4];
		    System.out.println(question);
		    System.out.println(answer1+" "+answer2+" "+answer3+" "+answer4);
		    String right = items[5];
		    boolean chance = true;
		    Timer timer = new Timer();
		    timer.schedule(new MyTask1(),0,15000);
		    System.out.println("Please enter your answer!");
		    int grade = 0;
		    long startTime = System.currentTimeMillis();
		    MyTask circumstance = new MyTask() ;
		    boolean circum = circumstance.getCir();
		    if(circum) {
		    	Scanner scan = new Scanner(System.in);
		        String answer = scan.next();
		        chance = false;
		        long endTime = System.currentTimeMillis();
				long usedTime = (endTime-startTime)/1000;
				if(answer==right) {
					grade = grade+getGrade(usedTime);
				}
	        System.out.println(answer);
	        System.out.println(usedTime);
		    System.out.println(grade);
		    }
		}
	}
		public static int getGrade(long n) {
			if(n<=5) {
				return 300;
			}
			else if(n>5&&n<=10) {
				return 200;
			}
			else {
				return 100;
			}
		}
}

package duizhanzhuye;
import java.util.Scanner;

public class Denglu {
	public static void main(String[] arg) {
    	Scanner scan = new Scanner(System.in);
	    String name = scan.next();
	    String code = scan.next();
	    //��������ֵ0:�û������ڣ�1���ɹ���½��2���������
	    int logMood = getMood(name,code);
	    if(logMood == 0) {
		    System.out.println("You haven't got a perssion!");
	    }
	    else if (logMood == 2) {
		    System.out.println("LOG SUCESSFULLY");
	    }
	    else {
		    System.out.println("WRONG CODE");
	    }
	}
	public static int getMood(String m,String n) {
		if(m=="luzhangchi"||m=="lyl"||m=="lzh") {
			if(n=="12345678") {
				return 1;
			}
			else {
				return 2;
			}
		}
		else {
			return 0;
		}
	}
}

package duizhanzhuye;

class book{
	static String bookName;
	static int bookPrice;
	static String bookText;
	public static void setBookName(String s) {
		bookName = s;
	}
	public static void setBookPrice(int n) {
		bookPrice = n;
	}
	public static void setBookText(String str) {
		bookText = str;
	}
	static String getBookText() {
		return bookText;
	}
	static int getBookPrice() {
		return bookPrice;
	}
	static String getBookName() {
		return bookName;
	}
}
public class shop {
	public static int currentMoney = 2000;
	public static void buyBook(int n) {
		int money = getMoney();
		if(n==1) {
			money = money - 300;
		}
		else if(n==2) {
			money = money - 200;
	    }
	    else if(n==3) {
	    	money = money - 250;
	    }
	    else {
	    	money = money;
	    }
		currentMoney = money;
	}
	public static int getMoney() {
		return currentMoney;
	}
	public static void showMoney() {
		System.out.println(currentMoney);
	}
	public static void main(String[] args) {
		buyBook(1);
		currentMoney = getMoney();
		showMoney();
		book bookOne = new book();
		bookOne.setBookName("<<Head First Java>>");
		bookOne.setBookPrice(200);
		bookOne.setBookText("This is a very good book!");
		System.out.println(bookOne.getBookPrice());
		System.out.println(bookOne.getBookText());
		System.out.println(bookOne.getBookName());
	}
	  

}

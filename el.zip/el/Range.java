package duizhanzhuye;

public class Range {
	public static void main(String[] args) {
	    //("1:luzhangchi:260;2:liuyulin:230;3:lzh:160")
	    String rateText = "1:luzhangchi:260;2:liuyulin:230;3:lzh:160";
	    String[] rateItems = rateText.split(";");
	    for(int i=0;i<rateItems.length;i++) {
		    String[] ratePerson = rateItems[i].split(":");
		    System.out.println("No."+ratePerson[0]+" "+ratePerson[1]+" "+ratePerson[2]);
	    }
	}
}
